﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Store_Online.Models;
using Store_Online.Modules.Garage.Models;
using Store_Online.Modules.Garage.Repositories;
using Store_Online.Shared.Notifications;

namespace Store_Online.Modules.Garage.Pages
{
    public partial class GarageCustomerRegistration : Page
    {
        private readonly CustomerRepository _customerRepository;

        public GarageCustomerRegistration(CustomerRepository customerRepository)
        {
            InitializeComponent();

            _customerRepository = customerRepository;

            InitializeForm();
        }

        private void InitializeForm()
        {
            btnSave.IsEnabled = true;
            btnUpdate.IsEnabled = false;

            rdoMale.IsChecked = true;
            cboStatus.SelectedIndex = 0;
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtCustomerName.Text))
            {
                MessageBox.Show(
                    "Customer Name is required.",
                    "Validation",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                txtCustomerName.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtPhone.Text))
            {
                MessageBox.Show(
                    "Phone Number is required.",
                    "Validation",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);




                txtPhone.Focus();
                return false;
            }

            if (!dtpDateOfBirth.SelectedDate.HasValue)
            {
                MessageBox.Show(
                    "Date of Birth is required.",
                    "Validation",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                dtpDateOfBirth.Focus();
                return false;
            }

            return true;
        }

        private CustomerModel BuildCustomerModel(string command)
        {
            return new CustomerModel
            {
                Command = command,
                BranchCode = AppSession.BranchCode,
                CustomerId = txtCustomerCode.Text.Trim(),
                CustomerName = txtCustomerName.Text.Trim(),
                Gender = rdoMale.IsChecked == true ? "Male" : "Female",
                DateOfBirth = dtpDateOfBirth.SelectedDate,
                Phone = txtPhone.Text.Trim(),
                Email = txtEmail.Text.Trim(),
                Province = cboProvince.Text.Trim(),
                Status = (cboStatus.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Active",
                Remark = txtRemark.Text.Trim(),
                CreatedBy = AppSession.Email.ToString()
            };
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!ValidateInput())
                    return;

                CustomerModel customer = BuildCustomerModel("I");

                string customerId = _customerRepository.Save(customer);

                if (string.IsNullOrWhiteSpace(customerId))
                {

                    NotificationService.Success(
    "Customer saved successfully.");


                    return;
                }

                txtCustomerCode.Text = customerId;

                NotificationService.Success(
"Customer saved successfully.");

                btnSave.IsEnabled = false;
                btnUpdate.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!ValidateInput())
                    return;

                CustomerModel customer = BuildCustomerModel("U");

                string customerId = _customerRepository.Save(customer);

                if (string.IsNullOrWhiteSpace(customerId))
                {
                    MessageBox.Show(
                        "Unable to update customer.",
                        "Garage Management System",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    return;
                }

                txtCustomerCode.Text = customerId;

                MessageBox.Show(
                    "Customer updated successfully.",
                    "Garage Management System",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            txtCustomerCode.Clear();
            txtCustomerName.Clear();
            txtPhone.Clear();
            txtEmail.Clear();
            txtRemark.Clear();

            rdoMale.IsChecked = true;

            cboProvince.SelectedIndex = -1;
            cboStatus.SelectedIndex = 0;

            dtpDateOfBirth.SelectedDate = null;

            btnSave.IsEnabled = true;
            btnUpdate.IsEnabled = false;

            txtCustomerName.Focus();
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService?.CanGoBack == true)
            {
                NavigationService.GoBack();
            }
        }
    }
}

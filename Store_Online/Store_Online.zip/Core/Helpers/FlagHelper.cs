using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Online.Core.Helpers
{
    public static class FlagHelper
    {
        public const string US = "pack://application:,,,/Shared/Assets/Flags/us.png";
        public const string KH = "pack://application:,,,/Shared/Assets/Flags/kh.png";
        public const string CN = "pack://application:,,,/Shared/Assets/Flags/cn.png";
        public const string JP = "pack://application:,,,/Shared/Assets/Flags/jp.png";
    }
}

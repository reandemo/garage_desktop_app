﻿using Store_Online.Models;
using System.Windows;
using System.Windows.Controls;

namespace Store_Online.Core.Controls
{
    public partial class UserProfileMenu : UserControl
    {
        public UserProfileMenu()
        {
            InitializeComponent();

            UserName = string.IsNullOrWhiteSpace(AppSession.Email)
                ? "Guest"
                : AppSession.Email;

            UserRole = string.IsNullOrWhiteSpace(AppSession.RoleName)
                ? "User"
                : AppSession.RoleName;

            UserEmail = AppSession.Email;
        }

        public string UserName
        {
            get => (string)GetValue(UserNameProperty);
            set => SetValue(UserNameProperty, value);
        }

        public static readonly DependencyProperty UserNameProperty =
            DependencyProperty.Register(nameof(UserName), typeof(string), typeof(UserProfileMenu));

        public string UserRole
        {
            get => (string)GetValue(UserRoleProperty);
            set => SetValue(UserRoleProperty, value);
        }

        public static readonly DependencyProperty UserRoleProperty =
            DependencyProperty.Register(nameof(UserRole), typeof(string), typeof(UserProfileMenu));

        public string UserEmail
        {
            get => (string)GetValue(UserEmailProperty);
            set => SetValue(UserEmailProperty, value);
        }

        public static readonly DependencyProperty UserEmailProperty =
            DependencyProperty.Register(nameof(UserEmail), typeof(string), typeof(UserProfileMenu));

        public event EventHandler? LogoutRequested;

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            LogoutRequested?.Invoke(this, EventArgs.Empty);
        }
    }
}

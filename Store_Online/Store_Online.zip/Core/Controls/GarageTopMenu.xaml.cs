﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Store_Online.Core.Controls
{
    /// <summary>
    /// Interaction logic for GarageTopMenu.xaml
    /// </summary>
    public partial class GarageTopMenu : UserControl
    {
        /// <summary>
        /// Raised whenever a menu item is clicked.
        /// The string parameter is the MenuItem.Tag value.
        /// </summary>
        public event EventHandler<string>? MenuClicked;

        public GarageTopMenu()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles all menu navigation.
        /// </summary>
        private void Menu_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not MenuItem menuItem)
                return;

            if (menuItem.Tag is string tag)
            {
                MenuClicked?.Invoke(this, tag);
            }
        }

        /// <summary>
        /// Exit application.
        /// </summary>
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
                "Are you sure you want to exit the application?",
                "Exit",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }
    }
}

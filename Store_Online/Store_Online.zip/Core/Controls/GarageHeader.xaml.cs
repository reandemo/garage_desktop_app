﻿using Store_Online.Core.Helpers;
using Store_Online.Core.Localization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace Store_Online.Core.Controls
{
    /// <summary>
    /// Interaction logic for GarageHeader.xaml
    /// </summary>
    public partial class GarageHeader : UserControl
    {
        public GarageHeader()
        {
            InitializeComponent();

            Loaded += GarageHeader_Loaded;
        }

        private void GarageHeader_Loaded(object sender, RoutedEventArgs e)
        {
            LoadCurrentLanguage();
        }

        private void LoadCurrentLanguage()
        {
            switch (LanguageManager.CurrentCulture.Name)
            {
                case "km-KH":
                    txtCurrentLanguage.Text = "Khmer";
                    imgCurrentLanguage.Source =
                        new BitmapImage(new Uri(FlagHelper.KH, UriKind.Absolute));
                    break;

                case "zh-CN":
                    txtCurrentLanguage.Text = "Chinese";
                    imgCurrentLanguage.Source =
                        new BitmapImage(new Uri(FlagHelper.CN, UriKind.Absolute));
                    break;

                case "ja-JP":
                    txtCurrentLanguage.Text = "Japanese";
                    imgCurrentLanguage.Source =
                        new BitmapImage(new Uri(FlagHelper.JP, UriKind.Absolute));
                    break;

                default:
                    txtCurrentLanguage.Text = "English";
                    imgCurrentLanguage.Source =
                        new BitmapImage(new Uri(FlagHelper.US, UriKind.Absolute));
                    break;
            }
        }

        private void Chinese_Click(object sender, RoutedEventArgs e)
        {
            LanguageManager.ChangeCulture("zh-CN");
            LoadCurrentLanguage();
        }

        private void English_Click(object sender, RoutedEventArgs e)
        {
            LanguageManager.ChangeCulture("en-US");
            LoadCurrentLanguage();
        }

        private void Khmer_Click(object sender, RoutedEventArgs e)
        {
            LanguageManager.ChangeCulture("km-KH");
            LoadCurrentLanguage();
        }
    }
}

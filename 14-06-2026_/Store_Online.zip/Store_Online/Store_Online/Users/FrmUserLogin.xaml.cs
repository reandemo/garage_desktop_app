﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Store_Online.Users
{
    /// <summary>
    /// Interaction logic for FrmUserLogin.xaml
    /// </summary>
    public partial class FrmUserLogin : Window
    {
        public FrmUserLogin()
        {
            InitializeComponent();
            Loaded += (s, e) =>
            {
                txtUserlogin.Focus();
            };
        }

        private void Btn_setupstore_Click(object sender, RoutedEventArgs e)
        {
            FrmStoreSetup frm = new FrmStoreSetup();
            frm.ShowDialog();
        }

        private void Btn_Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void txtPassword_KeyDown(
    object sender,
    KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                btnLogin.RaiseEvent(
                    new RoutedEventArgs(Button.ClickEvent));
            }
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }
    }

}

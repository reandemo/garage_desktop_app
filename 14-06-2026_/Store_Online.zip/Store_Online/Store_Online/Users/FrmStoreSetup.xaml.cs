﻿using System.Windows;

namespace Store_Online.Users
{
    /// <summary>
    /// Interaction logic for FrmStoreSetup.xaml
    /// </summary>
    public partial class FrmStoreSetup : Window
    {
        public FrmStoreSetup()
        {
            InitializeComponent();
        }

        private void btnCreateStore_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
